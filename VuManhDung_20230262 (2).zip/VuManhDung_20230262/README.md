# Ứng Dụng Sức Khỏe

Ứng dụng theo dõi sức khỏe cá nhân với tính năng tính BMI, nhịp tim, CO2 và đưa ra lời khuyên cá nhân hóa, bao gồm AI lời khuyên khi có cảnh báo.

## Cấu Trúc Dự Án

- `src/`: Mã nguồn chính
  - `main.py`: Ứng dụng GUI chính
- `data/`: Dữ liệu lưu trữ
  - `data.json`: File lưu trữ dữ liệu sức khỏe
- `tests/`: Các file kiểm thử
  - `test_main.py`: Kiểm thử các hàm cơ bản

## Cách Chạy

1. Kích hoạt virtual environment:
   ```
   & .venv\Scripts\Activate.ps1
   ```

2. Chạy ứng dụng:
   ```
   python src/main.py
   ```

3. Chạy kiểm thử:
   ```
   python tests/test_main.py
   ```

## Tính Năng

- Nhập dữ liệu sức khỏe (chiều cao, cân nặng, nhịp tim, CO2)
- Tính BMI và phân loại
- Kiểm tra cảnh báo (nhịp tim bất thường, CO2 cao)
- Đưa ra lời khuyên chế độ ăn, tập luyện, nghỉ ngơi
- AI lời khuyên khi có cảnh báo
- Xem lịch sử và thống kê

## Yêu Cầu

- Python 3.x
- Tkinter (thường có sẵn với Python)