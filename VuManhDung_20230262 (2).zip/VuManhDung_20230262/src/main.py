﻿import json
import os
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
from datetime import datetime

FILE_NAME = "../data/data.json"
HEART_RATE_MIN = 50
HEART_RATE_MAX = 100
CO2_MAX = 1000


def load_data():
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_data(data):
    with open(FILE_NAME, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def calculate_bmi(weight, height):
    return weight / ((height / 100) ** 2)


def bmi_status(bmi):
    if bmi < 18.5:
        return "Thiếu cân"
    elif bmi < 25:
        return "Bình thường"
    elif bmi < 30:
        return "Thừa cân"
    return "Béo phì"


def heart_rate_status(hr):
    if hr < 50:
        return "Quá thấp (nguy hiểm)"
    elif hr < 60:
        return "Thấp (bình thường)"
    elif hr <= 100:
        return "Bình thường"
    elif hr <= 120:
        return "Cao (cảnh báo)"
    return "Quá cao (nguy hiểm)"


def check_warnings(heart_rate, co2):
    warnings = []

    if heart_rate < HEART_RATE_MIN:
        warnings.append("Nhịp tim quá thấp")
    elif heart_rate > HEART_RATE_MAX:
        warnings.append("Nhịp tim quá cao")

    if co2 > CO2_MAX:
        warnings.append("CO2 cao")

    return warnings


class HealthApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ứng dụng quản lý sức khỏe")
        self.geometry("1100x850")
        self.configure(bg="#f0f4f8")
        self.resizable(False, False)
        self.data = load_data()
        
        self.create_widgets()
        self.update_status("Mời bạn nhập dữ liệu sức khỏe và bấm Lưu dữ liệu.")
        self.draw_summary_chart()

    def create_widgets(self):
        header_frame = tk.Frame(self, bg="#2c3e50", height=80)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        title = tk.Label(header_frame, text="Ứng dụng quản lý sức khỏe", font=("Segoe UI", 22, "bold"), bg="#2c3e50", fg="#ecf0f1")
        title.pack(pady=(16, 4))
        
        subtitle = tk.Label(header_frame, text="Theo dõi BMI • Nhịp tim • CO2 • Thống kê chi tiết", font=("Segoe UI", 11), bg="#2c3e50", fg="#bdc3c7")
        subtitle.pack(pady=(0, 12))

        main_container = tk.Frame(self, bg="#f0f4f8")
        main_container.pack(fill=tk.BOTH, expand=True, padx=16, pady=(16, 10))

        left_section = tk.Frame(main_container, bg="#f0f4f8")
        left_section.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 12))

        form_frame = tk.Frame(left_section, bg="#ffffff", bd=0, highlightbackground="#d0d8e0", highlightthickness=1)
        form_frame.pack(fill=tk.X, pady=(0, 12))

        for col in range(4):
            form_frame.columnconfigure(col, weight=1, uniform="col")

        header = tk.Label(form_frame, text="📋 Nhập chỉ số sức khỏe", font=("Segoe UI", 13, "bold"), bg="#ffffff", fg="#2c3e50")
        header.grid(row=0, column=0, columnspan=4, sticky="w", padx=16, pady=(14, 10))

        label_config = {"font": ("Segoe UI", 10), "bg": "#ffffff", "fg": "#34495e"}
        entry_config = {"font": ("Segoe UI", 10), "bd": 1, "relief": "solid", "width": 20}

        tk.Label(form_frame, text="Chiều cao (cm)", **label_config).grid(row=1, column=0, sticky="w", padx=16, pady=8)
        self.height_var = tk.StringVar()
        height_entry = tk.Entry(form_frame, textvariable=self.height_var, **entry_config)
        height_entry.grid(row=1, column=1, padx=8, pady=8, sticky="ew")

        tk.Label(form_frame, text="Cân nặng (kg)", **label_config).grid(row=1, column=2, sticky="w", padx=16, pady=8)
        self.weight_var = tk.StringVar()
        weight_entry = tk.Entry(form_frame, textvariable=self.weight_var, **entry_config)
        weight_entry.grid(row=1, column=3, padx=8, pady=8, sticky="ew")

        tk.Label(form_frame, text="Nhịp tim (lần/phút)", **label_config).grid(row=2, column=0, sticky="w", padx=16, pady=8)
        self.heart_rate_var = tk.StringVar()
        hr_entry = tk.Entry(form_frame, textvariable=self.heart_rate_var, **entry_config)
        hr_entry.grid(row=2, column=1, padx=8, pady=8, sticky="ew")

        tk.Label(form_frame, text="CO2 (ppm)", **label_config).grid(row=2, column=2, sticky="w", padx=16, pady=8)
        self.co2_var = tk.StringVar()
        co2_entry = tk.Entry(form_frame, textvariable=self.co2_var, **entry_config)
        co2_entry.grid(row=2, column=3, padx=8, pady=8, sticky="ew")

        self.save_button = tk.Button(form_frame, text="💾 Lưu dữ liệu", command=self.submit_record, bg="#27ae60", fg="white", activebackground="#229954", bd=0, font=("Segoe UI", 10, "bold"), width=18)
        self.save_button.grid(row=3, column=0, columnspan=2, pady=16, padx=16, sticky="w")

        self.clear_button = tk.Button(form_frame, text="🗑️ Xóa form", command=self.clear_form, bg="#95a5a6", fg="white", activebackground="#7f8c8d", bd=0, font=("Segoe UI", 10), width=18)
        self.clear_button.grid(row=3, column=2, columnspan=2, pady=16, padx=16, sticky="e")

        output_frame = tk.Frame(left_section, bg="#ffffff", bd=0, highlightbackground="#d0d8e0", highlightthickness=1)
        output_frame.pack(fill=tk.BOTH, expand=True)

        output_label = tk.Label(output_frame, text="📊 Kết quả / Thống kê", font=("Segoe UI", 12, "bold"), bg="#ffffff", fg="#2c3e50")
        output_label.pack(anchor="w", padx=16, pady=(14, 10))

        self.output_text = scrolledtext.ScrolledText(output_frame, font=("Segoe UI", 9), wrap=tk.WORD, bd=0, relief=tk.FLAT, bg="#f8fafb", fg="#2c3e50")
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 14))
        self.output_text.config(state=tk.DISABLED)

        right_section = tk.Frame(main_container, bg="#ffffff", bd=0, highlightbackground="#d0d8e0", highlightthickness=1, width=340)
        right_section.pack(side=tk.RIGHT, fill=tk.BOTH)
        right_section.pack_propagate(False)

        chart_title = tk.Label(right_section, text="📈 Biểu đồ thống kê", font=("Segoe UI", 12, "bold"), bg="#ffffff", fg="#2c3e50")
        chart_title.pack(anchor="w", padx=14, pady=(14, 8))

        self.chart_canvas = tk.Canvas(right_section, width=320, height=320, bg="#f8fafb", bd=0, highlightthickness=0)
        self.chart_canvas.pack(padx=14, pady=(0, 14))

        stats_label = tk.Label(right_section, text="📌 Thông tin nhanh", font=("Segoe UI", 11, "bold"), bg="#ffffff", fg="#2c3e50")
        stats_label.pack(anchor="w", padx=14, pady=(8, 6))

        self.stats_text = tk.Label(right_section, text="", font=("Segoe UI", 9), bg="#ffffff", fg="#2c3e50", justify=tk.LEFT)
        self.stats_text.pack(anchor="w", padx=14, pady=(0, 14))

        button_frame = tk.Frame(self, bg="#f0f4f8", height=60)
        button_frame.pack(fill=tk.X, padx=16, pady=(10, 16))
        button_frame.pack_propagate(False)

        btn_style = {"font": ("Segoe UI", 10, "bold"), "bd": 0, "width": 16, "padx": 8, "pady": 10}
        tk.Button(button_frame, text="📋 Thống kê", command=self.show_summary, bg="#3498db", fg="white", activebackground="#2980b9", **btn_style).pack(side=tk.LEFT, padx=6)
        tk.Button(button_frame, text="📜 Lịch sử", command=self.show_history, bg="#e67e22", fg="white", activebackground="#d35400", **btn_style).pack(side=tk.LEFT, padx=6)
        tk.Button(button_frame, text="⚠️ Cảnh báo", command=self.show_alerts, bg="#e74c3c", fg="white", activebackground="#c0392b", **btn_style).pack(side=tk.LEFT, padx=6)
        tk.Button(button_frame, text="❌ Thoát", command=self.quit, bg="#2c3e50", fg="white", activebackground="#1a252f", **btn_style).pack(side=tk.LEFT, padx=6)

    def clear_form(self):
        self.height_var.set("")
        self.weight_var.set("")
        self.heart_rate_var.set("")
        self.co2_var.set("")

    def update_status(self, text):
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(tk.END, text)
        self.output_text.config(state=tk.DISABLED)

    def update_quick_stats(self):
        if not self.data:
            self.stats_text.config(text="Chưa có dữ liệu")
            return
        
        total = len(self.data)
        latest = self.data[-1]
        
        stats_text = f"Lần cuối: {latest['time']}\nBMI: {latest['bmi']} ({latest['status']})\nNhịp tim: {latest['heart_rate']} lần/phút\nCO2: {latest['co2']} ppm\nTổng ghi nhận: {total}"
        self.stats_text.config(text=stats_text)

    def submit_record(self):
        try:
            height = float(self.height_var.get())
            weight = float(self.weight_var.get())
            heart_rate = int(self.heart_rate_var.get())
            co2 = int(self.co2_var.get())
        except ValueError:
            messagebox.showerror("Lỗi dữ liệu", "Vui lòng nhập số hợp lệ cho tất cả các trường.")
            return

        bmi = calculate_bmi(weight, height)
        status = bmi_status(bmi)
        warnings = check_warnings(heart_rate, co2)

        record = {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "height": height,
            "weight": weight,
            "bmi": round(bmi, 2),
            "status": status,
            "heart_rate": heart_rate,
            "co2": co2,
            "warnings": warnings,
        }

        self.data.append(record)
        save_data(self.data)
        self.clear_form()

        message = [f"✅ Đã lưu dữ liệu lúc {record['time']}", f"BMI: {record['bmi']} ({status})", f"Nhịp tim: {heart_rate_status(heart_rate)}"]
        if warnings:
            message.append("⚠️ Cảnh báo:")
            message.extend([f"  • {w}" for w in warnings])
        else:
            message.append("✅ Mọi chỉ số đều bình thường")

        self.update_status("\n".join(message))
        self.update_quick_stats()
        self.draw_summary_chart()

    def show_summary(self):
        if not self.data:
            messagebox.showinfo("Thống kê", "Chưa có dữ liệu để thống kê.")
            return

        total = len(self.data)
        avg_bmi = round(sum(r["bmi"] for r in self.data) / total, 2)
        avg_hr = round(sum(r["heart_rate"] for r in self.data) / total, 1)
        avg_co2 = round(sum(r["co2"] for r in self.data) / total, 1)
        
        max_bmi = max(r["bmi"] for r in self.data)
        min_bmi = min(r["bmi"] for r in self.data)
        max_hr = max(r["heart_rate"] for r in self.data)
        min_hr = min(r["heart_rate"] for r in self.data)
        max_co2 = max(r["co2"] for r in self.data)
        min_co2 = min(r["co2"] for r in self.data)
        
        bmi_categories = {
            "Thiếu cân": sum(1 for r in self.data if r["status"] == "Thiếu cân"),
            "Bình thường": sum(1 for r in self.data if r["status"] == "Bình thường"),
            "Thừa cân": sum(1 for r in self.data if r["status"] == "Thừa cân"),
            "Béo phì": sum(1 for r in self.data if r["status"] == "Béo phì"),
        }
        
        warning_count = sum(1 for r in self.data if r["warnings"])
        
        text = (
            f"{'='*50}\n"
            f"THỐNG KÊ TỔNG QUÁT SỨC KHỎE\n"
            f"{'='*50}\n\n"
            f"📊 TỔNG QUAN:\n"
            f"  • Tổng số lần ghi nhận: {total}\n"
            f"  • Số lần cảnh báo: {warning_count}\n\n"
            
            f"📈 CHỈ SỐ BMI:\n"
            f"  • Trung bình: {avg_bmi}\n"
            f"  • Cao nhất: {max_bmi}\n"
            f"  • Thấp nhất: {min_bmi}\n"
            f"  • Phân loại: Thiếu cân ({bmi_categories['Thiếu cân']}) | Bình thường ({bmi_categories['Bình thường']}) | Thừa cân ({bmi_categories['Thừa cân']}) | Béo phì ({bmi_categories['Béo phì']})\n\n"
            
            f"❤️ CHỈ SỐ NHỊP TIM:\n"
            f"  • Trung bình: {avg_hr} lần/phút\n"
            f"  • Cao nhất: {max_hr} lần/phút\n"
            f"  • Thấp nhất: {min_hr} lần/phút\n\n"
            
            f"💨 CHỈ SỐ CO2:\n"
            f"  • Trung bình: {avg_co2} ppm\n"
            f"  • Cao nhất: {max_co2} ppm\n"
            f"  • Thấp nhất: {min_co2} ppm\n"
        )
        
        if warning_count:
            text += f"\n⚠️ CẢNH BÁO ({warning_count} lần):\n"
            for r in self.data:
                if r["warnings"]:
                    text += f"  • {r['time']}: {', '.join(r['warnings'])}\n"

        self.update_status(text)
        self.update_quick_stats()
        self.draw_summary_chart()

    def show_history(self):
        if not self.data:
            messagebox.showinfo("Lịch sử", "Chưa có dữ liệu lịch sử.")
            return

        lines = ["LỊCH SỬ GHI NHẬN:\n"]
        for idx, r in enumerate(self.data, 1):
            lines.append(f"{idx}. {r['time']}")
            lines.append(f"   Chiều cao: {r['height']} cm  |  Cân nặng: {r['weight']} kg")
            lines.append(f"   BMI: {r['bmi']} ({r['status']})  |  Nhịp tim: {r['heart_rate']} lần/phút ({heart_rate_status(r['heart_rate'])})")
            lines.append(f"   CO2: {r['co2']} ppm  |  Cảnh báo: {', '.join(r['warnings']) if r['warnings'] else 'Không có'}\n")

        self.update_status("\n".join(lines))
        self.update_quick_stats()
        self.draw_summary_chart()

    def show_alerts(self):
        warning_records = [r for r in self.data if r["warnings"]]
        if not warning_records:
            messagebox.showinfo("Cảnh báo", "Chưa có cảnh báo bất thường.")
            return

        lines = ["CẢNH BÁO BẤT THƯỜNG:\n"]
        for r in warning_records:
            lines.append(f"⚠️ {r['time']}")
            lines.append(f"   {' | '.join(r['warnings'])}\n")

        self.update_status("\n".join(lines))
        self.update_quick_stats()
        self.draw_summary_chart()

    def draw_summary_chart(self):
        self.chart_canvas.delete("all")
        if not self.data:
            self.chart_canvas.create_text(160, 160, text="Chưa có dữ liệu", font=("Segoe UI", 11), fill="#7f8c8d")
            return

        total = len(self.data)
        values = [
            round(sum(r["bmi"] for r in self.data) / total, 2),
            round(sum(r["heart_rate"] for r in self.data) / total, 1),
            round(sum(r["co2"] for r in self.data) / total, 1),
        ]
        labels = ["BMI", "Nhịp tim", "CO2"]
        colors = ["#3498db", "#e74c3c", "#f39c12"]

        width = 320
        height = 320
        padding_x = 50
        padding_y = 40
        max_value = max(values) * 1.2
        if max_value == 0:
            max_value = 1

        self.chart_canvas.create_text(width / 2, 15, text="Giá trị trung bình", font=("Segoe UI", 11, "bold"), fill="#2c3e50")

        for i, value in enumerate(values):
            bar_width = 60
            spacing = 30
            bar_x0 = padding_x + i * (bar_width + spacing)
            bar_x1 = bar_x0 + bar_width
            bar_height = int((value / max_value) * (height - padding_y - 50))
            bar_y0 = height - padding_y - bar_height
            bar_y1 = height - padding_y
            self.chart_canvas.create_rectangle(bar_x0, bar_y0, bar_x1, bar_y1, fill=colors[i], outline="")
            self.chart_canvas.create_text((bar_x0 + bar_x1) / 2, bar_y1 + 16, text=labels[i], font=("Segoe UI", 9, "bold"), fill="#2c3e50")
            self.chart_canvas.create_text((bar_x0 + bar_x1) / 2, bar_y0 - 10, text=str(value), font=("Segoe UI", 9, "bold"), fill=colors[i])

        for step in range(4):
            y = padding_y + step * (height - padding_y - 30) / 3
            line_value = round(max_value * (1 - step / 3), 1)
            self.chart_canvas.create_line(padding_x - 8, y, width - 20, y, fill="#ecf0f1", dash=(2, 2))
            self.chart_canvas.create_text(padding_x - 22, y, text=str(line_value), font=("Segoe UI", 8), fill="#7f8c8d")

        self.chart_canvas.create_line(padding_x - 8, padding_y, padding_x - 8, height - padding_y, fill="#95a5a6", width=2)
        self.chart_canvas.create_line(padding_x - 8, height - padding_y, width - 20, height - padding_y, fill="#95a5a6", width=2)


if __name__ == "__main__":
    app = HealthApp()
    app.update_quick_stats()
    app.mainloop()
