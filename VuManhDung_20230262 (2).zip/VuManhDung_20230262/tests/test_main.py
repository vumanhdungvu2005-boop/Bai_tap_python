import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from main import calculate_bmi, bmi_status, check_warnings

def test_calculate_bmi():
    assert calculate_bmi(70, 170) == 70 / (1.7 ** 2)
    print("✅ test_calculate_bmi passed")

def test_bmi_status():
    assert bmi_status(16) == "Thiếu cân"
    assert bmi_status(22) == "Bình thường"
    assert bmi_status(27) == "Thừa cân"
    assert bmi_status(32) == "Béo phì"
    print("✅ test_bmi_status passed")

def test_check_warnings():
    assert "Nhịp tim quá thấp" in check_warnings(40, 500)
    assert "CO2 cao" in check_warnings(70, 1200)
    assert check_warnings(70, 500) == []
    print("✅ test_check_warnings passed")

if __name__ == "__main__":
    test_calculate_bmi()
    test_bmi_status()
    test_check_warnings()
    print("🎉 All tests passed!")